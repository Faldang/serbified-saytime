MUST be run from the command line.

running:
saytime
will give you the current time

running:
saytime test
will give you the test version

running:
saytime 16:54
(or any other time in this format) will give you the text version of that time.

The more adventurous among you can change their system time and date and try running saytime then.